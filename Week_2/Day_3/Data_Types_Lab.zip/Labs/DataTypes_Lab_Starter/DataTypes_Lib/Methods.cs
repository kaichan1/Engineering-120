﻿using System;

namespace DataTypes_Lib
{
    public static class Methods
    {
        // write a method to return the product of all numbers from 1 to n inclusive
        public static int Factorial(int n)
        {
            throw new NotImplementedException();
        }

        public static float Mult(float num1, float num2)
        {
            return num1 * num2;
        }
    }
}
