﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassesApp
{
    public class ShoppingList
    {
        public int Bread { get; set; }
        public int Milk { get; set; }
        public int Soap { get; set; }
        public int Potato { get; set; }
        public int Lemon { get; set; }
    }
}
