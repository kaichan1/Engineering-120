global using NUnit.Framework;
global using SafariParkApp;
