﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafariParkApp
{
    public class Shopping
    {
        public int Trousers { get; set; }
        public int Shirts { get; set; }
        public int Shoes { get; set; }
        public int Ties { get; set; }
        public int Socks { get; set; }
    }
}
