﻿namespace LambdaLab_Lib
{
    public class Exercsises
    {
        public static int CountTotalNumberOfSpartans(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        public static int CountTotalNumberOfSpartansInUKAndUSA(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        public static int NumberOfSpartansBornAfter1980(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        public static int SumOfAllSpartaMarksMoreThan50Inclusive(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        //To 2 decimal points
        public static double AverageSpartanMark(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        public static List<Spartan> SortByAlphabeticallyByLastName(List<Spartan> spartans)
        {
            throw new NotImplementedException();

        }

        public static List<string> ListAllDistinctCities(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }

        public static List<Spartan> ListAllSpartansWithIdBeginingWithB(List<Spartan> spartans)
        {
            throw new NotImplementedException();
        }
    }
}