<img src="https://boolerang.co.uk/wp-content/uploads/job-manager-uploads/company_logo/2018/04/SG-Logo-Black.png" alt="Sparta Logo" width="200"/>

# Lambda Expressions Lab

Before starting, explore the `Spartan` class and the tests. In the `SetUp` method of the tests review the `Spartan` information in the  list.

Implement all methods in *one line* using Lambda expressions e.g. `return myQuery.Count()`


